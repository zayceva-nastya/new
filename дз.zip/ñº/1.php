<?php
echo date();

?>