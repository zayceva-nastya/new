<?php 
$separator="====>=>"

?>